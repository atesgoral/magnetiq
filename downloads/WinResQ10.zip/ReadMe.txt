Win-Res-Q v1.0
The Lost Window Rescue Tool

(c)1998 Magnetiq

Check for updates at: http://www.magnetiq.com
