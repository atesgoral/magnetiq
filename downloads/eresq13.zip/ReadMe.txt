                E-Res-Q v1.3                 

  Simple e-mail reader and mailbox rescuer   

            (c)1998-2000 Magnetiq            

Check for updates at: http://www.magnetiq.com
Version 2.0 on its way...

---------------------------------------------

What's new?

  1.3
- Fixed contact info.
- Removed the splash.
- Removed resize restriction.
- Removed port. If you need to specify a non-
  standard port, write the server as:
  mail.yourserver.com:port
- Asks before disconnecting if there are
  deleted messages and Apply button hasn't been
  pressed.
- Decodes From and Date fields.
- Fixed a typo.
  
  1.2
- Fixed a parsing error that lead to a
  malfunction on some servers.
